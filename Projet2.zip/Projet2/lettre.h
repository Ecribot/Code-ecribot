#ifndef LETTRE_H
#define LETTRE_H

extern const unsigned int listecharactere[40][11][11];
extern int ordre[40];
void enter_exit_letter();

#endif
